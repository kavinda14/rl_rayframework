- I have included two .ipynb scripts.
- They both have the exact code, except map_DH is used in one and map_16 in the other.
- The file name will indicate, which map has been used in each script.
- I also just realized we can use LaTex to make these reports, which I will definitely do from next time onwards.
- The report.pdf has all the answers to the questions. 
- If anything else is needed, please let me know via senewiry@oregonstate.edu

Have fun :)