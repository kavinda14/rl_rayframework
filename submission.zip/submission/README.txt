A script was created for both ray_tutorial (ray_tutorial_completed.py) and map_reduce-2.py.
Run both scripts using python3 interpreter.
Line chart included for map reduce results.
The precise numbers for the map reduce results are included in map_reduce_results.txt.