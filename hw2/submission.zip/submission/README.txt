Notes to Aashish:

- The ray version used is the same as assignment 1: pip install ray=0.8.3
I kept getting the I/O errors in the distributed implementation, however it did produce an output so, I did not upgrade ray (also because of the fear that it might break my code).

- The competition code is essentially my distributed v2 code.

- The code to produce the graphs in report.pdf are available on hw2.ipynb (it contains code for all the graphs at the end), graph_timevsmaps.py (code for the performance of dist v1 and v2) and graph_timevsworkers.py (code for the performance with different number of workers. The code is provided for you to see the exact values I received as output when running on the different criteria.

Have fun marking! :)